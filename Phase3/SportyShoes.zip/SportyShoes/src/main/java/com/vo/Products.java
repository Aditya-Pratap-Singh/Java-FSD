package com.vo;

public class Products
{
	private String	pdtID;
	private String	pdtName;
	private String	pdtCategory;
	private String	pdtCost;
	private String	pdtOriginCountry;

	public String getPdtID()
	{
		return pdtID;
	}

	public void setPdtID(String pdtID)
	{
		this.pdtID = pdtID;
	}

	public String getPdtName()
	{
		return pdtName;
	}

	public void setPdtName(String pdtName)
	{
		this.pdtName = pdtName;
	}

	public String getPdtCategory()
	{
		return pdtCategory;
	}

	public void setPdtCategory(String pdtCategory)
	{
		this.pdtCategory = pdtCategory;
	}

	public String getPdtCost()
	{
		return pdtCost;
	}

	public void setPdtCost(String pdtCost)
	{
		this.pdtCost = pdtCost;
	}

	public String getPdtOriginCountry()
	{
		return pdtOriginCountry;
	}

	public void setPdtOriginCountry(String pdtOriginCountry)
	{
		this.pdtOriginCountry = pdtOriginCountry;
	}

}