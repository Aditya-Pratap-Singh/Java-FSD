package com.vo;

public class Customer 
{
	private String custID;
	private String custFirstName;
	private String custLastName;
	private String custEmail;
	private String custMob;
	private String userID;
	private String userPass;

	public String getCustID()
	{
		return custID;
	}
	public void setCustID(String custID)
	{
		this.custID = custID;
	}
	public String getCustFirstName()
	{
		return custFirstName;
	}
	public void setCustFirstName(String custFirstName)
	{
		this.custFirstName = custFirstName;
	}
	public String getCustLastName()
	{
		return custLastName;
	}
	public void setCustLastName(String custLastName)
	{
		this.custLastName = custLastName;
	}
	public String getCustEmail()
	{
		return custEmail;
	}
	public void setCustEmail(String custEmail)
	{
		this.custEmail = custEmail;
	}
	public String getCustMob()
	{
		return custMob;
	}
	public void setCustMob(String custMob)
	{
		this.custMob = custMob;
	}
	public String getUserID()
	{
		return userID;
	}
	public void setUserID(String userID)
	{
		this.userID = userID;
	}
	public String getUserPass()
	{
		return userPass;
	}
	public void setUserPass(String userPass)
	{
		this.userPass = userPass;
	}	
}