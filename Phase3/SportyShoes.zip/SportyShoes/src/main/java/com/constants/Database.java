package com.constants;

public class Database
{
	//public static String DB_CLASS_NAME = "com.mysql.jdbc.Driver";
	public static String DB_CLASS_NAME = "com.mysql.cj.jdbc.Driver";
	public static String DB_URL="jdbc:mysql://localhost:3306/sporty-shoes";
	public static String DB_USER="root";
	public static String DB_PASS="AZlm1@3a";
}
