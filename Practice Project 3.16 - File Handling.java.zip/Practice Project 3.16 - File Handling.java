package com;

import java.util.*;
import java.io.*;
//import java.io.IOExpection;

public class FileHandling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			File obj = new File("FileFile.txt");
		if(obj.createNewFile()) {
			System.out.println("File created: " + obj.getName());
		}
		else
			System.out.println("File already exists");
	}catch(IOException e) {
		System.out.println("Error occurred");
		e.printStackTrace();
	}
		
		try{FileWriter filwrit = new FileWriter("FileFile.txt");
		filwrit.write("Something is written");
		filwrit.close();
		System.out.println("Successfully written");
		}catch(IOException exc) {
			System.out.println("Error occurred");
			exc.printStackTrace();
		}
		
		
		try{File obj2 = new File("FileFile.txt");
		Scanner reader = new Scanner(obj2);
		while(reader.hasNextLine()) {
			String data = reader.nextLine();
			System.out.println(data);
			
			reader.close();
		}
		}catch(FileNotFoundException exception) {
			System.out.println("Error occurred");
			exception.printStackTrace();
		}	
	}
}


